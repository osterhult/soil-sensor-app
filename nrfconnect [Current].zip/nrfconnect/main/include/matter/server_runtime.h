#pragma once

namespace matter
{
namespace server_runtime
{

void InitEventLogging();
void ConfigureDynamicMrp();
void InitWifiCommissioningCluster();

} // namespace server_runtime
} // namespace matter

