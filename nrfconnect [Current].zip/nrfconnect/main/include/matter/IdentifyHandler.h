#pragma once

// Initialize Identify cluster runtime hooks.
void IdentifyHandler_Init();
