#pragma once

namespace sensors
{
namespace soil_moisture_sensor
{

void Init();

} // namespace soil_moisture_sensor
} // namespace sensors

