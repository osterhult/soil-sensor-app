/*
 *    Project-specific AppEvent translation unit to align with Nordic sample layout.
 */

#include "app/AppEvent.h"
