#include "timesync_stub.h"

#include <app/AttributeAccessInterfaceRegistry.h>
#include <app/CommandHandlerInterface.h>
#include <app/CommandHandlerInterfaceRegistry.h>
#include <app/ConcreteAttributePath.h>
#include <app/util/attribute-storage.h>
#include <app-common/zap-generated/cluster-objects.h>
#include <app/clusters/time-synchronization-server/time-synchronization-server.h>
#include <protocols/interaction_model/Constants.h>
#include <lib/support/CodeUtils.h>
#include <lib/support/logging/CHIPLogging.h>

namespace matter {
namespace timesync {
namespace {

constexpr chip::EndpointId kDefaultEndpoint = 0;
constexpr chip::ClusterId kClusterId        = chip::app::Clusters::TimeSynchronization::Id;

constexpr chip::AttributeId kUtcTime             = 0x0000;
constexpr chip::AttributeId kGranularity         = 0x0001;
constexpr chip::AttributeId kTimeSource          = 0x0002;
constexpr chip::AttributeId kTimeZone            = 0x0005;
constexpr chip::AttributeId kDstOffset           = 0x0006;
constexpr chip::AttributeId kGeneratedCommandList = 0xFFF8;
constexpr chip::AttributeId kAcceptedCommandList  = 0xFFF9;
constexpr chip::AttributeId kEventList            = 0xFFFA;
constexpr chip::AttributeId kAttributeList        = 0xFFFB;
constexpr chip::AttributeId kFeatureMap           = 0xFFFC;
constexpr chip::AttributeId kClusterRevision      = 0xFFFD;

class TimeSyncInterface : public chip::app::AttributeAccessInterface, public chip::app::CommandHandlerInterface
{
public:
    explicit TimeSyncInterface(chip::EndpointId endpoint) :
        chip::app::AttributeAccessInterface(chip::MakeOptional(endpoint), kClusterId),
        chip::app::CommandHandlerInterface(chip::MakeOptional(endpoint), kClusterId), mEndpoint(endpoint)
    {}

    CHIP_ERROR Read(const chip::app::ConcreteReadAttributePath & path,
                    chip::app::AttributeValueEncoder & encoder) override
    {
        if (path.mEndpointId != mEndpoint || path.mClusterId != kClusterId)
        {
            return CHIP_NO_ERROR;
        }

        switch (path.mAttributeId)
        {
        case kUtcTime:
            return encoder.EncodeNull();
        case kGranularity:
            return encoder.Encode(static_cast<uint8_t>(0));
        case kTimeSource:
            return encoder.Encode(static_cast<uint8_t>(0));
        case kTimeZone:
        case kDstOffset:
            return CHIP_IM_GLOBAL_STATUS(UnsupportedAttribute);
        case kFeatureMap:
            return encoder.Encode(static_cast<uint32_t>(0));
        case kClusterRevision:
            return encoder.Encode(static_cast<uint16_t>(2));
        case kAttributeList: {
            const chip::AttributeId kAttrs[] = {
                kUtcTime, kGranularity, kTimeSource, kFeatureMap, kClusterRevision,
            };
            return encoder.EncodeList([&](auto listEncoder) -> CHIP_ERROR {
                for (auto attr : kAttrs)
                {
                    ReturnErrorOnFailure(listEncoder.Encode(attr));
                }
                return CHIP_NO_ERROR;
            });
        }
        case kAcceptedCommandList:
            return encoder.EncodeList([](auto listEncoder) -> CHIP_ERROR {
                ReturnErrorOnFailure(listEncoder.Encode(static_cast<chip::CommandId>(
                    chip::app::Clusters::TimeSynchronization::Commands::SetUTCTime::Id)));
                return CHIP_NO_ERROR;
            });
        case kGeneratedCommandList:
        case kEventList:
            return encoder.EncodeList([](auto) { return CHIP_NO_ERROR; });
        default:
            return CHIP_IM_GLOBAL_STATUS(UnsupportedAttribute);
        }
    }

    void InvokeCommand(chip::app::CommandHandlerInterface::HandlerContext & handlerContext) override
    {
        using namespace chip::app::Clusters::TimeSynchronization::Commands;

        switch (handlerContext.mRequestPath.mCommandId)
        {
        case SetUTCTime::Id:
            HandleCommand<SetUTCTime::DecodableType>(handlerContext, [](auto & ctx, const auto &) {
                ctx.mCommandHandler.AddStatus(ctx.mRequestPath, chip::Protocols::InteractionModel::Status::Success);
            });
            break;
        default:
            break;
        }
    }

private:
    chip::EndpointId mEndpoint;
};

TimeSyncInterface & GetInterface(chip::EndpointId endpoint)
{
    static TimeSyncInterface sInterface(kDefaultEndpoint);
    if (endpoint != kDefaultEndpoint)
    {
        static TimeSyncInterface sAltInterface(endpoint);
        return sAltInterface;
    }
    return sInterface;
}

} // namespace

void RegisterAttrAndCommands(chip::EndpointId endpoint)
{
    TimeSyncInterface & iface = GetInterface(endpoint);

    if (!chip::app::AttributeAccessInterfaceRegistry::Instance().Register(&iface))
    {
        ChipLogError(Zcl, "TimeSync attr access already registered for endpoint %u", static_cast<unsigned>(endpoint));
    }

    if (chip::app::CommandHandlerInterfaceRegistry::Instance().RegisterCommandHandler(&iface) != CHIP_NO_ERROR)
    {
        ChipLogError(Zcl, "TimeSync command handler registration failed for endpoint %u", static_cast<unsigned>(endpoint));
    }
}

} // namespace timesync
} // namespace matter
