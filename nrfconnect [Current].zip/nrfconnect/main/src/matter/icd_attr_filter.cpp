#include "icd_attr_filter.h"

#include <app/AttributeAccessInterfaceRegistry.h>
#include <app/ConcreteAttributePath.h>
#include <app/util/attribute-storage.h>
#include <app-common/zap-generated/ids/Clusters.h>
#include <lib/support/CodeUtils.h>
#include <lib/support/logging/CHIPLogging.h>

namespace matter {
namespace icd {
namespace {

constexpr chip::ClusterId kClusterId        = chip::app::Clusters::IcdManagement::Id;
constexpr chip::AttributeId kIdleModeDuration    = 0x0000;
constexpr chip::AttributeId kActiveModeDuration  = 0x0001;
constexpr chip::AttributeId kActiveModeThreshold = 0x0002;
constexpr chip::AttributeId kRegisteredClients   = 0x0003;
constexpr chip::AttributeId kIcdCounter          = 0x0004;
constexpr chip::AttributeId kGeneratedCommandList = 0xFFF8;
constexpr chip::AttributeId kAcceptedCommandList  = 0xFFF9;
constexpr chip::AttributeId kEventList            = 0xFFFA;
constexpr chip::AttributeId kAttributeList        = 0xFFFB;
constexpr chip::AttributeId kFeatureMap           = 0xFFFC;
constexpr chip::AttributeId kClusterRevision      = 0xFFFD;

class IcdAttrAccess : public chip::app::AttributeAccessInterface
{
public:
    explicit IcdAttrAccess(chip::EndpointId endpoint) :
        chip::app::AttributeAccessInterface(chip::MakeOptional(endpoint), kClusterId), mEndpoint(endpoint)
    {}

    CHIP_ERROR Read(const chip::app::ConcreteReadAttributePath & path,
                    chip::app::AttributeValueEncoder & encoder) override
    {
        if (path.mEndpointId != mEndpoint || path.mClusterId != kClusterId)
        {
            return CHIP_NO_ERROR;
        }

        switch (path.mAttributeId)
        {
        case kIdleModeDuration:
        case kActiveModeDuration:
            return encoder.Encode(static_cast<uint32_t>(0));
        case kActiveModeThreshold:
            return encoder.Encode(static_cast<uint16_t>(0));
        case kRegisteredClients:
        case kIcdCounter:
            return CHIP_IM_GLOBAL_STATUS(UnsupportedAttribute);
        case kFeatureMap:
            return encoder.Encode(static_cast<uint32_t>(0));
        case kClusterRevision:
            return encoder.Encode(static_cast<uint16_t>(1));
        case kAttributeList: {
            const chip::AttributeId kAttrs[] = {
                kIdleModeDuration, kActiveModeDuration, kActiveModeThreshold, kFeatureMap, kClusterRevision,
            };
            return encoder.EncodeList([&](auto listEncoder) -> CHIP_ERROR {
                for (auto attr : kAttrs)
                {
                    ReturnErrorOnFailure(listEncoder.Encode(attr));
                }
                return CHIP_NO_ERROR;
            });
        }
        case kGeneratedCommandList:
        case kAcceptedCommandList:
        case kEventList:
            return encoder.EncodeList([](auto) { return CHIP_NO_ERROR; });
        default:
            return CHIP_IM_GLOBAL_STATUS(UnsupportedAttribute);
        }
    }

private:
    chip::EndpointId mEndpoint;
};

IcdAttrAccess & GetInterface(chip::EndpointId endpoint)
{
    static IcdAttrAccess sInterface(/*endpoint=*/0);
    if (endpoint != 0)
    {
        static IcdAttrAccess sAltInterface(endpoint);
        return sAltInterface;
    }
    return sInterface;
}

} // namespace

void RegisterAttrFilters(chip::EndpointId endpoint)
{
    IcdAttrAccess & iface = GetInterface(endpoint);
    if (!chip::app::AttributeAccessInterfaceRegistry::Instance().Register(&iface))
    {
        ChipLogError(Zcl, "ICD attr access already registered for endpoint %u", static_cast<unsigned>(endpoint));
    }
}

} // namespace icd
} // namespace matter
