#include <app/AttributeAccessInterface.h>
#include <app/AttributeAccessInterfaceRegistry.h>
#include <app/CommandHandlerInterface.h>
#include <app/CommandHandlerInterfaceRegistry.h>
#include <app/ConcreteAttributePath.h>
#include <app/clusters/time-synchronization-server/time-synchronization-server.h>
#include <app-common/zap-generated/cluster-objects.h>
#include <app-common/zap-generated/ids/Clusters.h>
#include <lib/support/logging/CHIPLogging.h>
#include <protocols/interaction_model/Constants.h>

namespace matter {
namespace cluster_overrides {
namespace {

constexpr chip::EndpointId kDefaultEndpoint = 0;
constexpr chip::ClusterId kClusterId        = chip::app::Clusters::TimeSynchronization::Id;

constexpr chip::AttributeId kUtcTime     = 0x0000;
constexpr chip::AttributeId kGranularity = 0x0001;
constexpr chip::AttributeId kTimeSource  = 0x0002;

class TimeSyncAttrAccess final : public chip::app::AttributeAccessInterface, public chip::app::CommandHandlerInterface
{
public:
    explicit TimeSyncAttrAccess(chip::EndpointId endpoint) :
        chip::app::AttributeAccessInterface(chip::MakeOptional(endpoint), kClusterId),
        chip::app::CommandHandlerInterface(chip::MakeOptional(endpoint), kClusterId), mEndpoint(endpoint)
    {}

    CHIP_ERROR Read(const chip::app::ConcreteReadAttributePath & path,
                    chip::app::AttributeValueEncoder & encoder) override
    {
        if (path.mEndpointId != mEndpoint || path.mClusterId != kClusterId)
        {
            return CHIP_NO_ERROR;
        }

        switch (path.mAttributeId)
        {
        case kUtcTime:
            return encoder.EncodeNull();
        case kGranularity:
            return encoder.Encode(static_cast<uint8_t>(0));
        case kTimeSource:
            return encoder.Encode(static_cast<uint8_t>(0));
        default:
            return CHIP_NO_ERROR;
        }
    }

    void InvokeCommand(chip::app::CommandHandlerInterface::HandlerContext & handlerContext) override
    {
        using namespace chip::app::Clusters::TimeSynchronization::Commands;

        if (handlerContext.mRequestPath.mCommandId == SetUTCTime::Id)
        {
            HandleCommand<SetUTCTime::DecodableType>(handlerContext, [](auto & ctx, const auto &) {
                ctx.mCommandHandler.AddStatus(ctx.mRequestPath, chip::Protocols::InteractionModel::Status::Success);
            });
        }
    }

private:
    chip::EndpointId mEndpoint;
};

TimeSyncAttrAccess & GetInterface(chip::EndpointId endpoint)
{
    static TimeSyncAttrAccess sDefaultInterface(kDefaultEndpoint);
    if (endpoint == kDefaultEndpoint)
    {
        return sDefaultInterface;
    }

    static TimeSyncAttrAccess sAltInterface(endpoint);
    return sAltInterface;
}

} // namespace

void RegisterTimeSyncOverride(chip::EndpointId endpoint)
{
    TimeSyncAttrAccess & iface = GetInterface(endpoint);

    if (!chip::app::AttributeAccessInterfaceRegistry::Instance().Register(&iface))
    {
        ChipLogError(Zcl, "TimeSync override already registered for endpoint %u", static_cast<unsigned>(endpoint));
    }

    CHIP_ERROR err = chip::app::CommandHandlerInterfaceRegistry::Instance().RegisterCommandHandler(&iface);
    if (err != CHIP_NO_ERROR)
    {
        ChipLogError(Zcl, "TimeSync command handler registration failed for endpoint %u", static_cast<unsigned>(endpoint));
    }
}

} // namespace cluster_overrides
} // namespace matter
