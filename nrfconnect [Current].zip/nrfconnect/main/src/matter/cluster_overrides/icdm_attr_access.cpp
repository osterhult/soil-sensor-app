#include <app/AttributeAccessInterface.h>
#include <app/AttributeAccessInterfaceRegistry.h>
#include <app/ConcreteAttributePath.h>
#include <app-common/zap-generated/ids/Clusters.h>
#include <lib/support/logging/CHIPLogging.h>

namespace matter {
namespace cluster_overrides {
namespace {

constexpr chip::EndpointId kDefaultEndpoint = 0;
constexpr chip::ClusterId kClusterId        = chip::app::Clusters::IcdManagement::Id;

constexpr chip::AttributeId kIdleModeDuration    = 0x0000;
constexpr chip::AttributeId kActiveModeDuration  = 0x0001;
constexpr chip::AttributeId kActiveModeThreshold = 0x0002;
constexpr chip::AttributeId kRegisteredClients   = 0x0003;
constexpr chip::AttributeId kIcdCounter          = 0x0004;

class IcdManagementAttrAccess final : public chip::app::AttributeAccessInterface
{
public:
    explicit IcdManagementAttrAccess(chip::EndpointId endpoint) :
        chip::app::AttributeAccessInterface(chip::MakeOptional(endpoint), kClusterId), mEndpoint(endpoint)
    {}

    CHIP_ERROR Read(const chip::app::ConcreteReadAttributePath & path,
                    chip::app::AttributeValueEncoder & encoder) override
    {
        if (path.mEndpointId != mEndpoint || path.mClusterId != kClusterId)
        {
            return CHIP_NO_ERROR;
        }

        switch (path.mAttributeId)
        {
        case kIdleModeDuration:
        case kActiveModeDuration:
            return encoder.Encode(static_cast<uint32_t>(0));
        case kActiveModeThreshold:
            return encoder.Encode(static_cast<uint16_t>(0));
        case kRegisteredClients:
        case kIcdCounter:
            return CHIP_IM_GLOBAL_STATUS(UnsupportedAttribute);
        default:
            return CHIP_NO_ERROR;
        }
    }

private:
    chip::EndpointId mEndpoint;
};

IcdManagementAttrAccess & GetInterface(chip::EndpointId endpoint)
{
    static IcdManagementAttrAccess sDefaultInterface(kDefaultEndpoint);
    if (endpoint == kDefaultEndpoint)
    {
        return sDefaultInterface;
    }

    static IcdManagementAttrAccess sAltInterface(endpoint);
    return sAltInterface;
}

} // namespace

void RegisterIcdManagementOverride(chip::EndpointId endpoint)
{
    IcdManagementAttrAccess & iface = GetInterface(endpoint);

    if (!chip::app::AttributeAccessInterfaceRegistry::Instance().Register(&iface))
    {
        ChipLogError(Zcl, "ICD override already registered for endpoint %u", static_cast<unsigned>(endpoint));
    }
}

} // namespace cluster_overrides
} // namespace matter
