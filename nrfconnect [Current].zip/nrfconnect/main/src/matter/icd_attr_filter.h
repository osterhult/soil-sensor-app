#pragma once

#include <lib/core/DataModelTypes.h>

namespace matter {
namespace icd {

void RegisterAttrFilters(chip::EndpointId endpoint);

} // namespace icd
} // namespace matter

