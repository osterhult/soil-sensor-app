#pragma once

#include <lib/core/DataModelTypes.h>

namespace matter {
namespace timesync {

void RegisterAttrAndCommands(chip::EndpointId endpoint);

} // namespace timesync
} // namespace matter

