#pragma once

namespace SoilMeasurementNrf {
    void Start(); // starts periodic soil moisture publishing
}